rm *.class;rm */*.class
