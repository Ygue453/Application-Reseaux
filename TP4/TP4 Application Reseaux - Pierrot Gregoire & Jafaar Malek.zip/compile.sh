javac *.java;javac */*.java
